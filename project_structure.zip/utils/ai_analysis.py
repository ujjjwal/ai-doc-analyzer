# AI content analysis functions
