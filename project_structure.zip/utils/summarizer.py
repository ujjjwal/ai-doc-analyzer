# Summarization utilities
