# Handles text extraction from PDF, DOCX, and TXT files
