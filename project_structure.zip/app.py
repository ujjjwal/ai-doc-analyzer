# Main Streamlit app

import streamlit as st

st.title('AI Document Analyzer')
